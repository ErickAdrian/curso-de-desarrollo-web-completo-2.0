<?php
require "twitteroauth/autoload.php";
use Abraham\TwitterOAuth\TwitterOAuth;
$CONSUMER_KEY="fSH3CSloT8S2aIJY5eDUPeh2v";
$CONSUMER_SECRET="GxjR1XkEV2ExugYscvEHM4vrrwKH8R9WVBgUw0BU808oRZEidN";
$access_token="737398104777994240-DUxIzxYVD6Tl9mn60ArOUh3GBRx4rI9";
$access_token_secret="6kIXI5w1COElE3Lx8fTD2aUeJOgfap0qELM3O1leTg4ap";
$connection = new TwitterOAuth($CONSUMER_KEY, $CONSUMER_SECRET, $access_token, $access_token_secret);
$content = $connection->get("account/verify_credentials");
$statuses = $connection->get("statuses/home_timeline", ["count" => 25, "exclude_replies" => true]);
$statues = $connection->post("statuses/update", ["status" => "Mi tercer tweet!!!"]);

print_r($statuses);
?>