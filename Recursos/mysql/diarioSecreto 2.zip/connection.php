<?php

        $enlace=mysqli_connect("176.32.230.53","cl60-dsecreto","EMk/XhGF-","cl60-dsecreto");
        
        if (mysqli_connect_error())
        {
            die("Error de conexión a la base de datos");
        }

?>