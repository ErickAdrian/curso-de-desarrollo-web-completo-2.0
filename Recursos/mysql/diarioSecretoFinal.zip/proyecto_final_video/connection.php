<?php
    $enlace = mysqli_connect("176.32.230.53","cl60-diario","XDU.NgTC.","cl60-diario");
    if (mysqli_connect_error())
    {
    die("Error de conexión en la base de datos");

    }
?>