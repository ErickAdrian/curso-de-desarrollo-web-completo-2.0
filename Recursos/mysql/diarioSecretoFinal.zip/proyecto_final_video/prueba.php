<?php
    session_start();

    echo "<p>Usuario con sesion iniciada ".$_SESSION['username'];
?>