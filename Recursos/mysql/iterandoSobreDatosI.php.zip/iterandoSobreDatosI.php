<?php

    // Conexion con la base de datos
    header("Content-type:text/html;charset=utf-8");
    $enlace = mysqli_connect("176.32.230.53", "cl60-usuarios", "rs/4VVqXT", "cl60-usuarios");

    if (!$enlace) {
        echo "Error: No se pudo conectar a MySQL." . PHP_EOL;
        echo "errno de depuración: " . mysqli_connect_errno() . PHP_EOL;
        echo "error de depuración: " . mysqli_connect_error() . PHP_EOL;
    }
    else
    {
        $acentos = $enlace->query("SET NAMES 'utf8'");
        $query = "SELECT * from usuarios WHERE id>=5";
        if ($result = mysqli_query($enlace,$query))
        {
            while ($fila = mysqli_fetch_array($result))
            {
                print_r($fila); echo "<BR>";
                echo $fila['nombreUsuario'];
            }
            
        }
    }

    mysqli_close($enlace);

?>