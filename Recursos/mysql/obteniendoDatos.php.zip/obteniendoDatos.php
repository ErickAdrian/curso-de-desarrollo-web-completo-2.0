<?php

    // Conexion con la base de datos
    header("Content-type:text/html;charset=utf-8");
    $enlace = mysqli_connect("176.32.230.53", "cl60-usuarios", "rs/4VVqXT", "cl60-usuarios");

    if (!$enlace) {
        echo "Error: No se pudo conectar a MySQL." . PHP_EOL;
        echo "errno de depuración: " . mysqli_connect_errno() . PHP_EOL;
        echo "error de depuración: " . mysqli_connect_error() . PHP_EOL;
    }
    else
    {
        $query = "SELECT * from usuarios";
        if ($result = mysqli_query($enlace,$query))
        {
            $fila = mysqli_fetch_array($result);
            echo "Tu nombre de usuario es ".$fila[1]." y tu password es ".$fila[2];
        }
    }

    mysqli_close($enlace);

?>