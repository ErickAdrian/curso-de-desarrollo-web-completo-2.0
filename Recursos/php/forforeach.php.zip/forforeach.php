<?php
    header("Content-type: text/html;charset=\"utf-8\"");
    $familia = Array("Penélope","Jose Luis","Antonio","Pepe");
    echo "<h1>Familia</h1>";
    
    foreach ($familia as $clave=>$valor)
    {
        echo "<p>$familia[$clave] = $valor</p>";   
    }
        
    echo "<p>Fin del for</p>";
?>  