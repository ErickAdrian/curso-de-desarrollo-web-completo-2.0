<?php

echo "<html><head><title>Hola Mundo</title></head><body><h1>Hola Mundo!</h1></body></html>";

?>