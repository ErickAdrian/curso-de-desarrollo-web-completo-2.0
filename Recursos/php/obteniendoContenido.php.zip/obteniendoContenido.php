<?php
    header("Content-type:text/html;charset=\"utf-8\"");
    include("ficheroIncluido.php");
    echo file_get_contents("http://www.ecowebhosting.co.uk/");
?>