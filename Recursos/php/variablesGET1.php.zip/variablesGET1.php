<?php
    header("Content-type: text/html;charset=\"utf-8\"");
    if ($_GET)
        echo "<h1>Hola ".$_GET['nombre']."</h1><br>";
?>

<form>
    Escribe tu nombre:
    <input name="nombre" type="text">
    <input type="submit" value="Enviar">
</form>