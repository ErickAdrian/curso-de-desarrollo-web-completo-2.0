<?php
    header("Content-type: text/html;charset=\"utf-8\"");
    if ($_POST)
    {
        $usuarios = array("Jose Luis","Penélope","Antonio","Pepe");
        $esConocido=false;
        
        foreach ($usuarios as $valor)
        {
            if ($valor == $_POST['nombre'])
            {
                $esConocido=true;
            }
        }
        if ($esConocido)
        {
            echo "<h1>Bienvenido ".$_POST['nombre']."!</h1>";   
        }
        else
        {
            echo "<h1>Usuario incorrecto!</h1>";
        }
    }
?>

<form method="POST">
    ¿Cuál es tu nombre?
    <input name="nombre" type="text">
    <input type="submit" value="Enviar">
</form>