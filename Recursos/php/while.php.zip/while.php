<?php
    header("Content-type: text/html;charset=\"utf-8\"");
    $familia = Array("Penélope","Jose Luis","Antonio","Pepe");

    $i=0;
    while ($i<sizeof($familia))
    {
        
        //Intrucciones a repetir
        echo "<p>$familia[$i]</p>";
        //Modificación de i
        $i++;
    }
?>